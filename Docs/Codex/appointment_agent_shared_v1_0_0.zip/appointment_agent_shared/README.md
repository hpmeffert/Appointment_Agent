# Appointment Agent Shared Package v1.0.0

This package provides the first concrete shared Python module backbone for the LEKAB Appointment Agent platform.

Included modules:
- `commands.py`
- `events.py`
- `models.py`
- `errors.py`
- `validators.py`
- `enums.py`
- `ids.py`

Recommended repo target:
`apps/shared/v1_0_0/appointment_agent_shared/`
