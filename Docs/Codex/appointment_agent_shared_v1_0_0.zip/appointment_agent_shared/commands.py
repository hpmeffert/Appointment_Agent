from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class SearchSlotsCommand(BaseModel):
    tenant_id: str
    journey_id: str
    customer_id: Optional[str] = None
    service_type: str
    duration_minutes: int
    date_window_start: str
    date_window_end: str
    preferred_month: Optional[str] = None
    preferred_weekdays: List[str] = Field(default_factory=list)
    preferred_daypart: Optional[str] = None
    timezone: str
    resource_candidates: List[str] = Field(default_factory=list)
    location_type: Optional[str] = None
    max_slots: int = 5

class HoldSlotCommand(BaseModel):
    journey_id: str
    customer_id: Optional[str] = None
    slot_id: str
    hold_duration_minutes: int
    reason: Optional[str] = None

class ReleaseSlotHoldCommand(BaseModel):
    journey_id: str
    hold_id: str
    reason: Optional[str] = None

class CreateBookingCommand(BaseModel):
    tenant_id: str
    journey_id: str
    customer_id: Optional[str] = None
    booking_reference: str
    slot_id: str
    calendar_target: str
    title: str
    description: Optional[str] = None
    attendees: List[Dict[str, Any]] = Field(default_factory=list)
    timezone: str
    crm_reference: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class UpdateBookingCommand(BaseModel):
    booking_reference: str
    provider_reference: str
    new_start: Optional[str] = None
    new_end: Optional[str] = None
    new_title: Optional[str] = None
    new_description: Optional[str] = None
    attendees: List[Dict[str, Any]] = Field(default_factory=list)
    reason: Optional[str] = None

class CancelBookingCommand(BaseModel):
    booking_reference: str
    provider_reference: str
    reason: Optional[str] = None
    requested_by: Optional[str] = None

class ResolveCustomerCommand(BaseModel):
    tenant_id: str
    mobile_number: Optional[str] = None
    email: Optional[str] = None
    external_customer_id: Optional[str] = None
    crm_reference: Optional[str] = None
    channel: Optional[str] = None
    locale: Optional[str] = None

class UpsertCustomerCommand(BaseModel):
    customer_profile: Dict[str, Any]

class LaunchAppointmentWorkflowCommand(BaseModel):
    correlation_id: str
    booking_reference: Optional[str] = None
    lekab_job_template_id: Optional[str] = None
    job_name: str
    message_text: Optional[str] = None
    recipient_phone_numbers: List[str] = Field(default_factory=list)
    saved_tag_filters: List[str] = Field(default_factory=list)
    groups: List[str] = Field(default_factory=list)
    custom_tag_filter: Optional[str] = None
    exclude_numbers: List[str] = Field(default_factory=list)
    exclude_filter: Optional[str] = None
    scheduled_start: Optional[str] = None
    response_goal: Optional[int] = None
    keep_existing_recipients: bool = False
    metadata: Dict[str, Any] = Field(default_factory=dict)

class HandleProviderCallbackCommand(BaseModel):
    provider: str
    raw_payload: Dict[str, Any]
    headers: Dict[str, Any] = Field(default_factory=dict)
    received_at_utc: str
    remote_ip: Optional[str] = None
