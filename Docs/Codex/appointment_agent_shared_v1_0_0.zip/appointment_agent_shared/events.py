from datetime import datetime, timezone
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

class EventEnvelope(BaseModel):
    event_id: str
    event_type: str
    payload_version: str = "v1.0.0"
    timestamp_utc: str = Field(default_factory=utc_now_iso)
    correlation_id: str
    causation_id: Optional[str] = None
    trace_id: str
    tenant_id: str
    journey_id: str
    source: str
    idempotency_key: str
    payload: Dict[str, Any]

class CommandEnvelope(BaseModel):
    command_id: str
    command_type: str
    payload_version: str = "v1.0.0"
    timestamp_utc: str = Field(default_factory=utc_now_iso)
    correlation_id: str
    causation_id: Optional[str] = None
    trace_id: str
    tenant_id: str
    journey_id: str
    source: str
    idempotency_key: str
    payload: Dict[str, Any]
