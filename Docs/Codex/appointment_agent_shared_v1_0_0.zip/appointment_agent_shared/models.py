from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from .enums import BookingStatus, JourneyState, SlotHoldStatus

class ProviderReference(BaseModel):
    provider: str
    external_id: str
    operation: Optional[str] = None

class AppointmentJourney(BaseModel):
    journey_id: str
    tenant_id: str
    correlation_id: str
    customer_id: Optional[str] = None
    channel: Optional[str] = None
    service_type: Optional[str] = None
    locale: Optional[str] = None
    timezone: Optional[str] = None
    current_state: JourneyState = JourneyState.NEW
    created_at_utc: Optional[str] = None
    updated_at_utc: Optional[str] = None
    booking_reference: Optional[str] = None
    active_provider: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class CustomerProfile(BaseModel):
    customer_id: str
    external_customer_id: Optional[str] = None
    display_name: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    company_name: Optional[str] = None
    mobile_number: Optional[str] = None
    email: Optional[str] = None
    preferred_language: Optional[str] = None
    timezone: Optional[str] = None
    country: Optional[str] = None
    region: Optional[str] = None
    consent_messaging: Optional[bool] = None
    consent_reminders: Optional[bool] = None
    crm_reference: Optional[str] = None
    lekab_contact_id: Optional[str] = None
    google_person_resource_name: Optional[str] = None
    status: Optional[str] = None
    created_at_utc: Optional[str] = None
    updated_at_utc: Optional[str] = None

class AppointmentPreference(BaseModel):
    earliest_date: Optional[str] = None
    latest_date: Optional[str] = None
    preferred_month: Optional[str] = None
    preferred_weekdays: List[str] = Field(default_factory=list)
    preferred_daypart: Optional[str] = None
    preferred_location_type: Optional[str] = None
    preferred_language: Optional[str] = None
    urgency: Optional[str] = None
    free_text_preference: Optional[str] = None

class CandidateSlot(BaseModel):
    slot_id: str
    start_time: str
    end_time: str
    timezone: str
    resource_id: Optional[str] = None
    resource_type: Optional[str] = None
    location: Optional[str] = None
    score: Optional[float] = None
    hold_expires_at: Optional[str] = None
    provider: Optional[str] = None
    provider_reference: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class SlotHold(BaseModel):
    hold_id: str
    journey_id: str
    slot_id: str
    customer_id: Optional[str] = None
    created_at_utc: str
    expires_at_utc: str
    status: SlotHoldStatus = SlotHoldStatus.ACTIVE
    reason: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class AppointmentBooking(BaseModel):
    booking_reference: str
    journey_id: str
    customer_id: Optional[str] = None
    slot_id: Optional[str] = None
    status: BookingStatus = BookingStatus.PENDING
    provider: Optional[str] = None
    provider_reference: Optional[str] = None
    calendar_target: Optional[str] = None
    crm_reference: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    timezone: Optional[str] = None
    created_at_utc: Optional[str] = None
    updated_at_utc: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ConversationTurn(BaseModel):
    turn_id: str
    journey_id: str
    direction: str
    channel: str
    message_type: str
    provider: Optional[str] = None
    provider_reference: Optional[str] = None
    raw_payload_reference: Optional[str] = None
    normalized_payload: Dict[str, Any] = Field(default_factory=dict)
    timestamp_utc: str

class BookingResult(BaseModel):
    booking_reference: str
    provider: str
    provider_reference: str
    status: BookingStatus
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    timezone: Optional[str] = None
    calendar_target: Optional[str] = None
    attendees: List[Dict[str, Any]] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
