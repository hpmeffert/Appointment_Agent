from datetime import datetime

def require_non_empty(value: str, field_name: str) -> None:
    if not value or not str(value).strip():
        raise ValueError(f"{field_name} must not be empty")

def validate_iso_datetime(value: str, field_name: str) -> None:
    if not value:
        raise ValueError(f"{field_name} must not be empty")
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception as exc:
        raise ValueError(f"{field_name} must be ISO-8601 compatible") from exc
